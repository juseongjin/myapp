export declare enum TestEnum {
    A = 0,
    B = 1,
    C = 2
}
