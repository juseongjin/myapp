export { ArrayStruct, ArrayStructT } from './example/array-struct.js';
export { ArrayTable, ArrayTableT } from './example/array-table.js';
export { InnerStruct, InnerStructT } from './example/inner-struct.js';
export { NestedStruct, NestedStructT } from './example/nested-struct.js';
export { OuterStruct, OuterStructT } from './example/outer-struct.js';
export { TestEnum } from './example/test-enum.js';
