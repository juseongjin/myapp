export { FromInclude } from './other-name-space/from-include.js';
export { TableB, TableBT } from './other-name-space/table-b.js';
export { Unused, UnusedT } from './other-name-space/unused.js';
